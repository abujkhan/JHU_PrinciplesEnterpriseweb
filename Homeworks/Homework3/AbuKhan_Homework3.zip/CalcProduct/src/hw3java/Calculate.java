package hw3java;

/**
 *
 * @author Abu Khan
 * Project: HW 3 (Calculate Product of two integers)
 * Date: 9/19/2014
 */
public class Calculate {
    
    public int getProduct(int x, int y){
        
        return x*y;
    }
    
}
